package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoas {
	// atributos
	String matricula;

	// metodos
	public void realizarEmprestimo() {
		System.out.println(this.getNome() + "emprestimo realizado");
	}

	public void devolverLivro() {
		System.out.println(this.getNome() + " devolveu o livro");
	}
}
