package br.com.bibiotecasenai.principal;
import br.com.bibiotecasenai.itens.*;
import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		
		Bibliotecario bibliotecario = new Bibliotecario();
		Usuario usuario01 = new Usuario();
		Usuario usuario02 = new Usuario();
		
		for(int i = 0; i <= 10; i++) {
			usuario01.emprestarLivro();
		}
		
	}

}
