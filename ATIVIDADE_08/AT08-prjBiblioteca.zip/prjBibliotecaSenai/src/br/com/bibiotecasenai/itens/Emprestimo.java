package br.com.bibiotecasenai.itens;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Emprestimo {
	// Atributos
	int numeroEmprestimo;
	
	// metodos
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()+1);
	}
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()-1);
	}
}