package prjExercicio05;

public class ContaBancaria {
	// atributos
	int numero;
	String titular;
	private double saldo;

	// construtores

	public ContaBancaria() {

	}

	public ContaBancaria(int parametroNumero, String parametroTitular, double parametroSaldo) {
		this.numero = parametroNumero;
		this.titular = parametroTitular;
		this.saldo = parametroSaldo;
	}

	public void metodoDepositar() {
		System.out.println("depositado");
	}

	public void metodoSacar() {

		if (this.saldo > 0) {
			System.out.println("saque realizado");
		} else {
			System.out.println("Não á valor para ser sacadoS");
		}

	}

	// metodos getters setters
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
}
