package prjExercicio02;

public class Livro {
	// Atributos

	String titulo;
	String autor;
	int numPaginas;
	double preco;

	// Construtores

	public Livro() {

	}

	public Livro(String parametroTitulo, String parametroAutor, int parametroNumPaginas, double parametroPreco) {
		this.titulo = parametroTitulo;
		this.autor = parametroAutor;
		this.numPaginas = parametroNumPaginas;
		this.preco = parametroPreco;
	}

	// metodos
	public void aplicarDesconto() {
		if (this.preco <= 15) {
			System.out.println("Não é possivel aplicar desconto");
		} else {
			this.preco -= 15;
		}
	}

	public void exibirInfo() {
		System.out.println("Titulo " + this.titulo);
		System.out.println("Autor " + this.autor);
		System.out.println("Ele tem " + this.numPaginas + " paginas");
		System.out.println("O valor é de " + this.preco + " reais");
	}

	// getters e setters
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

}
