package prjExercicio02;

public class Aplicacao {

	public static void main(String[] args) {
		Livro RevolucaoDosBichos = new Livro("Revolução dos Bichos", "George Orwell", 144, 50);
		Livro TitoBang = new Livro("Tito Bang", "Caio Tozzi", 312, 12);
		Livro MilNovecentosOitentaQuatro = new Livro("1984", "George Orwell", 308, 45);

		RevolucaoDosBichos.aplicarDesconto();
		TitoBang.aplicarDesconto();
		MilNovecentosOitentaQuatro.aplicarDesconto();
		RevolucaoDosBichos.exibirInfo();
		TitoBang.exibirInfo();
		MilNovecentosOitentaQuatro.exibirInfo();
	}

}
