package prjExercicio01;

public class Carro {

	// Atributos

	String modelo;
	int ano;
	String marca;
	float valor;

	// Construtores

	public Carro() {

	}

	public Carro(String parametroModelo, int parametroAno, String parametroMarca, float parametroValor) {
		this.ano = parametroAno;
		this.modelo = parametroModelo;
		this.marca = parametroMarca;
		this.valor = parametroValor;

	}

	// metodos
	public void exibirInfo() {
		System.out.println("modelo " + this.modelo);
		System.out.println("ano " + this.ano);
		System.out.println("marca " + this.marca);
		System.out.println("Ele custa " + this.valor + "reais");
	}
}
