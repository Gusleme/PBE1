package prjExercicio01;

public class Aplicacao {

	public static void main(String[] args) {
		Carro Fiat = new Carro("Uno", 2008, "Fiat", 10000);
		Carro Hyundai = new Carro("Creta", 2023, "Hyundai", 100000);

		Fiat.exibirInfo();
		Hyundai.exibirInfo();

	}

}
