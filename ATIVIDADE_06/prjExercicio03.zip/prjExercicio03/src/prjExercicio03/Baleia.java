package prjExercicio03;

public class Baleia extends ClasseAnimal {
	public void metodoNadar() {
		System.out.println("Nadando");
	}
}
