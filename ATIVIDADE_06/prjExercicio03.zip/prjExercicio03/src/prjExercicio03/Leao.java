package prjExercicio03;

public class Leao extends ClasseAnimal {
	public void cacar() {
		System.out.println("caçando");
	}
}
