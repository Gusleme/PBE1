package prjExercicio03;

public class ClasseAnimal {
	// Atributos
	String nome;
	String raca;
	int idade;

	// Construtores
	public ClasseAnimal() {

	}

	public ClasseAnimal(String parametroNome, String parametroRaca, int parametroIdade) {
		this.nome = parametroNome;
		this.raca = parametroRaca;
		this.idade = parametroIdade;
	}

	// metodos
	public void fazerSom() {
		System.out.println("O animal fez um som");
	}
}
