package prjExercicio04;

public class Veiculo {
	// atributos
	String marca;
	String modelo;
	int velocidade;
	
	//construtores
	
	public Veiculo() {
		
	}
	
	public Veiculo(String parametroMarca, String parametroModelo, int parametroVelocidade) {
		this.marca = parametroMarca;
		this.modelo = parametroModelo;
		this.velocidade = parametroVelocidade;
	}
	public void metodoAcelerar() {
		this.velocidade += 10;

		System.out.println("Veiculo acelerando");
	}

	public void metodoFrear() {
		this.velocidade -= 10;

		System.out.println("veiculo freando");
	}
}
