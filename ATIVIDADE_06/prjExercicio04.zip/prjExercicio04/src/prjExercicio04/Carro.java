package prjExercicio04;

public class Carro extends Veiculo {
	@Override
	public void metodoAcelerar() {
		this.velocidade += 10;

		System.out.println("Carro está acelerando");
	}

	@Override
	public void metodoFrear() {
		this.velocidade -= 10;

		System.out.println("Carro está freando");
	}
}
