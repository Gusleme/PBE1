package br.com.bibliotecasenai.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibliotecasenai.entites.Editora;
import br.com.bibliotecasenai.repositories.EditoraRepository;

@Service
public class EditoraService {
	@Autowired
	private EditoraRepository editoraRepository;

	public Editora saveEditora(Editora editora) {
		return editoraRepository.save(editora);
	}

	public List<Editora> getALLEditora() {
		return editoraRepository.findAll();
	}

	public Editora getEditoraById(long id) {
		return editoraRepository.findById(id).orElse(null);
	}

	public void deleteEditora(long id) {
		editoraRepository.deleteById(id);
	}
}
