package br.com.bibliotecasenai.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bibliotecasenai.entites.Editora;
import br.com.bibliotecasenai.service.EditoraService;

@RestController
@RequestMapping("/editoras")
public class EditoraController {

	@Autowired
	private EditoraService editoraService;

	@PostMapping
	public Editora createLivro(Editora editora) {
		return editoraService.saveEditora(editora);
	}

	@GetMapping
	public List<Editora> getAllProdutos() {
		return editoraService.getALLEditora();
	}

	@GetMapping("/{id}")
	public Editora getProduto(@PathVariable long id) {
		return editoraService.getEditoraById(id);
	}

	@DeleteMapping("/{id}")
	public void deleteProduto(@PathVariable long id) {
		editoraService.deleteEditora(id);
	}
}
