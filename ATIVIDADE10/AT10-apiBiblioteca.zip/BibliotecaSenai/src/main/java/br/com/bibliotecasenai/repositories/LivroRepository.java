package br.com.bibliotecasenai.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.bibliotecasenai.entites.Livro;

public interface LivroRepository extends JpaRepository<Livro, Long> {

}
