package br.com.bibliotecasenai.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibliotecasenai.entites.Livro;
import br.com.bibliotecasenai.repositories.LivroRepository;

@Service
public class LivroService {

	@Autowired
	private LivroRepository livroRepository;

	public Livro saveLivro(Livro livro) {
		return livroRepository.save(livro);
	}

	public List<Livro> getALLlivros() {
		return livroRepository.findAll();
	}

	public Livro getLivroById(long id) {
		return livroRepository.findById(id).orElse(null);
	}

	public void deleteLivro(long id) {
		livroRepository.deleteById(id);
	}

}
