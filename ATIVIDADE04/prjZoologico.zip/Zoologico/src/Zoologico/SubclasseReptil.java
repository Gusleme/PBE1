package Zoologico;

public class SubclasseReptil extends ClasseAnimal {
	// metodos da subclasse

	public void trocarpele() {

	}

	public void rastejar() {

	}

	@Override
	public void MetodoEmitirSom() {
		System.out.println("SSSSSSSSSSSSS!");
	}
}
