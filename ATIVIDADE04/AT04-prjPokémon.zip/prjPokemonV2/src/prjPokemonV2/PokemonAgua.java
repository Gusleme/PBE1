package prjPokemonV2;

public class PokemonAgua extends Pokemon {
	// metodos da subclasse
	public void surfar() {

	}

	public void cannhaoAgua() {

	}

	@Override
	public void atacar() {
		System.out.println("Jato da agua");
	}
}
