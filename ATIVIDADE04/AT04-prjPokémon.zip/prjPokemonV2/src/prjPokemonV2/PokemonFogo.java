package prjPokemonV2;

public class PokemonFogo extends Pokemon {

	// metodos da subclasse
	public void bolaFogo() {

	}

	public void explosaoFogo() {

	}

	public void lancaChamas() {

	}

	@Override
	public void atacar() {
		System.out.println("Brasa");
	}
}
