package prjPokemonV2;

public class Pokemon {
	// atributos
	 String Nome;
	 String Tipo;
	 int Hp;
	 int Nivel;
	 int Defesa;

	// construtores
	 public Pokemon() {
		 
	 }
	 
	public Pokemon(String parametroNome, String parametroTipo, int parametroNivel, int parametroHp, int parametroDefesa) {
		this.Nome = parametroNome;
		this.Tipo = parametroTipo;
		this.Nivel = parametroNivel;
		this.Hp = parametroHp;
		this.Defesa = parametroDefesa;
	}
	// metodos
	public void atacar() {
		System.out.println("Atacou");
	}

	public void evoluir() {
		System.out.println("evoluindo");
	}
	public void exibirInfo() {
		System.out.println("Nome "+ this.Nome);
		System.out.println("Tipo "+ this.Tipo);
		System.out.println("Nivel "+ this.Nivel);
		System.out.println("Hp "+ this.Hp);
		System.out.println("Defesa "+ this.Defesa);
	}
	// setters e getters

	public String getNome() {
		return Nome;
	}
	
	public void setNome(String nome) {
		Nome = nome;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public int getHp() {
		return Hp;
	}

	public void setHp(int hp) {
		Hp = hp;
	}

	public int getNivel() {
		return Nivel;
	}

	public void setNivel(int nivel) {
		Nivel = nivel;
	}

	public int getDefesa() {
		return Defesa;
	}

	public void setDefesa(int defesa) {
		Defesa = defesa;
	}
}
