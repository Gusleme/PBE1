package prjPokemonV2;

public class PokemonVoador extends Pokemon {
	// metodos da subclasse
	public void voar() {

	}

	public void ataqueAsa() {

	}

	@Override
	public void atacar() {
		System.out.println("Bicada");
	}
}
