package prjPokemonV2;

import prjPokemonV2.Pokemon;

public class Apliacacao {

	public static void main(String[] args) {
		Pokemon Charmander = new Pokemon("Charmander", "Fogo", 15, 60, 40);
		Pokemon Flareon = new Pokemon("Flareon", "Fogo", 20, 90, 70);
		Pokemon Magicarp = new Pokemon("Magicarp", "Agua", 10, 50, 40);
		Pokemon Vaporeon = new Pokemon("Vaporeon", "Agua", 30, 100, 80);
		Pokemon Pidgey = new Pokemon("Pidgey", "Voador", 8, 40, 30);
		Pokemon hoothoot = new Pokemon("hoothoot", "Voador", 23, 70, 50);

		Charmander.atacar();
		Charmander.evoluir();
		Charmander.exibirInfo();

		Flareon.atacar();
		Flareon.evoluir();
		Flareon.exibirInfo();

		Magicarp.atacar();
		Magicarp.evoluir();
		Magicarp.exibirInfo();

		Vaporeon.atacar();
		Vaporeon.evoluir();
		Vaporeon.exibirInfo();

		Pidgey.atacar();
		Pidgey.evoluir();
		Pidgey.exibirInfo();

		hoothoot.atacar();
		hoothoot.evoluir();
		hoothoot.exibirInfo();

	}

}
